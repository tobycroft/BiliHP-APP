#/bin/sh
config() {
	read -p "是否启用bilihp(y/n),默认启用：" enable1
	if [ "$enable1" == "n" ] || [ "$enable1" == "N" ]; then
		enable=0
		enable1="yn"
	else
		enable=1
		enable1="y"
	fi

	read -p "输入服务名并回车:" name
	read -p "输入密码并回车:" password
	read -p "是否设置日志文件(y/n)，默认不设置:" log1
	if [ "$log1" == "y" ] || [] "$log1" == "Y" ]; then
		read -p "日志文件大小(Kib),默认为64:" logsize
		[ "$logsize" -gt 0 ] 2>/dev/null || logsize=64
		echo "日志文件路径：/tmp/bilihp/bilihp.log"
		log=1
	else
		log1="n"
		log=0
		logsize=64
	fi
	echo -e "平台名称：\n0.auto\n1.x86_64\n2.x86\n3.other\n4.自定义"
	read -p "请选择平台名称（建议选择auto）:" platforms1
	if [ "$platforms1" == 0 ]; then
		platforms="auto"
	elif [ "$platforms1" == 1 ]; then
		platforms="c2c_linux"
	elif [ "$platforms1" == 2 ]; then
		platforms="c2c_32_linux"
	elif [ "$platforms1" == 3 ]; then
		platforms="c2c_router_linux"
	else
		read -p "请输入平台名称:" platforms
	fi

	sleep 2s
	echo "是否启用bilihp：$enable1"
	echo "服务名为：$name"
	echo "密码为：$password"
	echo "是否设置日志文件：$log1"
	if [ "$log" == "1" ]; then
		echo "日志文件大小(Kib)：$logsize"
	fi
	echo "平台：$platforms"
	sleep 3s
	echo "保存配置中..."
	nvram set bilihp_enable=$enable
	nvram set bilihp_name=$name
	nvram set bilihp_password=$password
	nvram set bilihp_log=$log
	nvram set bilihp_logsize=$logsize
	nvram set bilihp_platforms=$platforms
	nvram commit
	echo "配置保存成功"

}


config
echo "复制bilihp到/etc/storage/bin/目录下"
cp -f ./bilihp /etc/storage/bin/
chmod +x /etc/storage/bin/bilihp
echo "创建目录/etc/storage/bilihp/"
mkdir -p /etc/storage/bilihp/
echo "复制bilihp_log_limit.sh到/etc/storage/bilihp/"
cp -f ./bilihp_log_limit.sh /etc/storage/bilihp/
echo "复制bilihp_update.sh到/etc/storage/bilihp/"
cp -f ./bilihp_update.sh /etc/storage/bilihp/
echo "复制bilihp_monitor.sh到/etc/storage/bilihp/"
cp -f ./bilihp_monitor.sh /etc/storage/bilihp/
chmod -R 755 /etc/storage/bilihp/

echo "sed -i '/logger -t \"【自定义脚本0】\" \"脚本完成\"/i\\/etc\/storage\/bilihp\/bilihp restart &' /etc/storage/script0_script.sh"
sed -i '/logger -t \"【自定义脚本0】\" \"脚本完成\"/i\\/etc\/storage\/bilihp\/bilihp restart &' /etc/storage/script0_script.sh

echo "保存storage"
/sbin/mtd_storage.sh save

echo "初始化完毕"
echo "启动bilihp中..."
/etc/storage/bin/bilihp start
echo "启动bilihp成功"

echo "可使用命令\"bilihp hlep\"查看帮助"
