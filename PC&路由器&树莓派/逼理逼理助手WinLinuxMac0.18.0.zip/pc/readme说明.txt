Centos，Ubuntu等Linux系统	：BiliHP_Linux_linux
苹果Mac电脑					：BiliHP_Mac_darwin
Openwrt路由器				：BiliHP_Router_linux
Windows32位					：BiliHP_PCWEB_386
Windows64位（一般用这个）	：BiliHP_PCWEB


Windows版本和linux等新版本均不会弹出浏览器（因为新增路由器版本），请手动访问
http://127.0.0.1
或者
http://localhost

如果部署在路由器，请访问：
http://127.0.0.1:79

后台运行功能，仅限登陆后使用